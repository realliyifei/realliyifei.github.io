# awesomeCV

My academic Curriculum Vitae tex files and PDF.

Latex template via https://github.com/posquit0/Awesome-CV
